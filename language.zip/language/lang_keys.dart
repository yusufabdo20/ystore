class LangKeys {
  static const String appName = 'app_name';
}
